package com.company;

public class Main {

    public static void main(String[] args) {
	Janela janela = new Janela();
	janela.abrir();
	janela.fechar();
	janela.pintar("Amarelo");
	janela.pintar("Preto");
	janela.pintar("Branco");
	janela.setDimensaoZ(0.75);
	janela.setDimensaoX(4.0);
	janela.setDimensaoY(1.5);
	System.out.println(janela.estaAberta(janela.getAberta()));
    }
}
