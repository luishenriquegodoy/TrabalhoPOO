package com.company;

public class Main {

    public static void main(String[] args) {
	Casa casa = new Casa();
	casa.setCor("Vermelha");
	casa.setJanela1("Fechada");
	casa.setJanela2("Aberta");
	casa.setJanela3("Fechada");
	casa.quantidadeJanelasAbertas();
    }
}
